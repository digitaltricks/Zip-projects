var app = angular.module('myApp');

app.controller('homeController',
    function ($scope, $rootScope) {
        $scope.user = $rootScope.user;
        
        $scope.scrollToTop = function(e){
            $("html, body").animate({ scrollTop: 0 }, "slow");
            return false;
        }
    }
);