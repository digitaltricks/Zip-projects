var app = angular.module('myApp');

app.controller('shoppingController',
    function ($scope, $rootScope, $timeout, $routeParams, $location) {
        $scope.message = 'Everyone come and see how good I look!'
        $scope.setContent = function (file) {
            alert(file);
        }
        $scope.goBackToPage = function (page) {
            $location.path('/shopping/'+page);
        }
        $scope.shopping = $routeParams.id || "home";

    }
);