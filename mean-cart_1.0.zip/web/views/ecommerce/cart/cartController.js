var app = angular.module('myApp');

app.controller('cartController',
    function ($scope, $localStorage, $location, ajaxFactory) {
        $scope.message = 'Everyone come and see how good I look!'
        $scope.cartData = $localStorage.cartData;
       
        $scope.cartTotal = function () {
            var total = 0;
            for (var i = 0; i < $scope.cartData.length; i++) {
                var item = $scope.cartData[i];
                total += item.quantity * item.product[0].price;
            }
            $scope.shipping = total * .05;
            return total + $scope.shipping;
        };
        $scope.goBackToProducts = function () {
            $location.path('/shopping/products');
        }
        $scope.checkout = function () {
            ajaxFactory.ajaxCall('POST', '/customers/update/cart',
                { updatedCart: $scope.cartData }).then(
                function (data, status, headers, config) {
                    $location.path('/shopping/shipping');
                }, function (data, status, headers, config) {
                    $window.alert(data);
                });
        };
    }
);