var app = angular.module('myApp');

app.controller('shoppingController',
    function ($scope, $rootScope, $timeout, $routeParams) {
        $scope.message = 'Everyone come and see how good I look!'
        $scope.setContent = function (file) {
            alert(file);
        }
        $scope.shopping = $routeParams.id || "home";

    }
);