var app = angular.module('myApp');

app.controller('ordersController',
    function ($scope, $rootScope) {
        $scope.message = 'Everyone come and see how good I look!'
        

    }
);