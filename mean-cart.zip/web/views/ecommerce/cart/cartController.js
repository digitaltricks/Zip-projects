var app = angular.module('myApp');

app.controller('cartController',
    function ($scope, $rootScope) {
        $scope.message = 'Everyone come and see how good I look!'
        

    }
);