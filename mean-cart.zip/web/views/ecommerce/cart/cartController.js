var app = angular.module('myApp');

app.controller('cartController',
    function ($scope, $localStorage, $location, ajaxFactory, $window) {
        $scope.notifyMssg = false;
        $scope.notifySuccess = false;
        $scope.notifyFailure = false;
        $scope.cartData = $localStorage.cartData;

        $scope.cartTotal = function () {
            var total = 0;
            for (var i = 0; i < $scope.cartData.length; i++) {
                var item = $scope.cartData[i];
                total += item.quantity * item.product[0].price;
            }
            $scope.shipping = total * .05;
            return total + $scope.shipping;
        };
        $scope.goBackToProducts = function () {
            $location.path('/shopping/products');
        }
        $scope.checkout = function () {
            ajaxFactory.ajaxCall('POST', '/customers/update/cart',
                { updatedCart: $scope.cartData }).then(
                function (data, status, headers, config) {
                    $location.path('/shopping/shipping');
                }, function (data, status, headers, config) {
                    $window.alert(data);
                });
        };

        $scope.deleteFromCart = function (productId) {
            for (var i = 0; i < $scope.customer.cart.length; i++) {
                var item = $scope.customer.cart[i];
                if (item.product[0]._id == productId) {
                    $scope.customer.cart.splice(i, 1);
                    break;
                }
            }
            ajaxFactory.ajaxCall('POST', '/customers/update/cart',
                { updatedCart: $scope.customer.cart }).then(
                function (data, status, headers, config) {
                    $scope.notifyMssg = true;
                    $scope.notifySuccess = true;
                    $scope.notifyFailure = false;
                },
                function (data, status, headers, config) {
                    $scope.notifyMssg = true;
                    $scope.notifyFailure = true;
                    $scope.notifySuccess = false;
                });
        };
    }
);