var app = angular.module('myApp');

app.controller('productsController',
    function ($scope, $rootScope) {
        $scope.message = 'Everyone come and see how good I look!'
        
        $scope.scrollToTop = function(e){
            $("html, body").animate({ scrollTop: 0 }, "slow");
            return false;
        }
    }
);