var app = angular.module('myApp');

app.controller('billingController',
    function ($scope, $localStorage, $location, ajaxFactory) {
        $scope.message = 'Everyone come and see how good I look!'
        
        $scope.customer = $localStorage.customer;
        $scope.months = [1,2,3,4,5,6,7,8,9,10,11,12];
        $scope.years = [2014,2015,2016,2017,2018,2019,2020];
        $scope.goBackToProducts = function () {
            $location.path('/shopping/products');
        }
        $scope.verifyBilling = function (ccv) {
            $scope.ccv = ccv;
            ajaxFactory.ajaxCall('POST', '/customers/update/billing',
                { updatedBilling: $scope.customer.billing[0] }).then(
                function (data, status, headers, config) {
                    $location.path('/shopping/review');
                }, function (data, status, headers, config) {
                    $window.alert(data);
                });
        };
       
    }
);