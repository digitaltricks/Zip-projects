var app = angular.module('myApp');

app.controller('signinController',
    function ($scope, $rootScope, $localStorage, ajaxFactory, $location, $cookies) {
        $scope.notifyMssg = false;
        $scope.notifySuccess = false;
        $scope.notifyFailure = false;

        $scope.closeAlert = function(alert){
            $scope[alert] = false;
        }

        $scope.submitSignin = function () {
            var newUser = {
                username: $scope.username,
                password: $scope.password
            };
            
            ajaxFactory.ajaxCall("POST", "/user/signin", newUser).then(
                function(response) {
                    console.log(response);
                    $cookies.put('token',response.token);
                    $cookies.put('currentUser',response.token);
    
                    $rootScope.token=response.token;
                    $rootScope.currentUser=$scope.username;
                    $localStorage.currentUser=$scope.username;

                    $scope.notifyMssg = true;
                    $scope.notifySuccess = true;
                    $scope.notifyFailure = false;
                    $location.path( "/shopping/home");
                },
                function(error) {
                    $scope.notifyMssg = true;
                    $scope.notifyFailure = true;
                    console.log(error);
                }
            );
        }
    }
);