var app = angular.module('myApp');

app.controller('reviewController',
    function ($scope, $localStorage, $location, ajaxFactory) {
        $scope.message = 'Everyone come and see how good I look!'
        
        $scope.customer = $localStorage.customer;
        $scope.goBackToProducts = function () {
            $location.path('/shopping/products');
        }
        $scope.setProduct = function (productId) {
            $scope.product = this.product;
            $location.path('/shopping/products');
        };
        $scope.cartTotal = function () {
            var total = 0;
            for (var i = 0; i < $scope.customer.cart.length; i++) {
                var item = $scope.customer.cart[i];
                total += item.quantity * item.product[0].price;
            }
            $scope.shipping = total * .05;
            return total + $scope.shipping;
        };
        $scope.makePurchase = function () {
            ajaxFactory.ajaxCall('POST', '/orders/add',
                {
                    orderBilling: $scope.customer.billing[0],
                    orderShipping: $scope.customer.shipping[0],
                    orderItems: $scope.customer.cart
                }).then(
                function (data, status, headers, config) {
                    $scope.customer.cart = [];
                    ajaxFactory.ajaxCall('GET', '/orders/get').then(
                        function (data, status, headers, config) {
                            $scope.orders = data;
                            $location.path('/shopping/order');
                        }, function (data, status, headers, config) {
                            $scope.orders = [];
                        }
                    );
                },
                function (data, status, headers, config) {
                    $window.alert(data);
                });
        };
    }
);