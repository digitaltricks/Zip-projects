var app = angular.module('myApp');

app.controller('productsController',
    function ($scope, $rootScope, ajaxFactory, $location, $localStorage) {
        $scope.message = 'Everyone come and see how good I look!'
        $scope.products = [];
        ajaxFactory.ajaxCall("GET", "/products/get").then(
            function (response) {
                console.log(response);
                $scope.products = response;
            },
            function (error) {
                console.log(error);
            }
        );
        ajaxFactory.ajaxCall("GET", "/customers/get").then(
            function (response) {
                console.log(response);
                $scope.customer = response;
                $localStorage.customer = response;
            },
            function (error) {
                $scope.customer = [];
                console.log(error);
            }
        );
        $scope.scrollToTop = function (e) {
            $("html, body").animate({ scrollTop: 0 }, "slow");
            return false;
        }
        $scope.setContent = function (filename) {
            $scope.content = '/static/' + filename;
        };
        $scope.setProduct = function (productId) {
            $scope.product = this.product;
            $scope.content = '/static/product.html';
        };
        
        $scope.addToCart = function (productId) {
            var found = false;
            for (var i = 0; i < $scope.customer.cart.length; i++) {
                var item = $scope.customer.cart[i];
                if (item.product[0]._id == productId) {
                    item.quantity += 1;
                    found = true;
                }
            }
            if (!found) {
                $scope.customer.cart.push({
                    quantity: 1,
                    product: [this.product]
                });
            }
            ajaxFactory.ajaxCall('POST', '/customers/update/cart',
                { updatedCart: $scope.customer.cart }).then(
                function (data, status, headers, config) {
                    $localStorage.cartData = $scope.customer.cart;
                    $location.path('/shopping/cart');
                }, function (data, status, headers, config) {
                    $window.alert(data);
                });
        };
        $scope.deleteFromCart = function (productId) {
            for (var i = 0; i < $scope.customer.cart.length; i++) {
                var item = $scope.customer.cart[i];
                if (item.product[0]._id == productId) {
                    $scope.customer.cart.splice(i, 1);
                    break;
                }
            }
            ajaxFactory.ajaxCall('POST', '/customers/update/cart',
                { updatedCart: $scope.customer.cart }).then(
                function (data, status, headers, config) {
                    $scope.content = '/static/cart.html';
                }, function (data, status, headers, config) {
                    $window.alert(data);
                });
        };
      
       
    }
);